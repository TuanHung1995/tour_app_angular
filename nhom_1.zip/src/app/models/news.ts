export interface News {
  id: number;
  title: string;
  image: string;
  content: string;
  tour_id: number;
  status: string;
  user_id: number;
  author: string;
  created_at: string;
}
