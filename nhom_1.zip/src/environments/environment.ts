export const environment = {
  apiUrl: ''
};